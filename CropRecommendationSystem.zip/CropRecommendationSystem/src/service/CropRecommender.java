package service;

import model.Crop;
import model.WeatherData;
import java.util.ArrayList;

/**
 * Holds the crop table and recommends crops for a set of weather data.
 */
public class CropRecommender {

    private final Crop[] crops = {
        //   name,        temp,    rainfall,   humidity
        new Crop("Rice",      20, 35, 100, 300, 60, 90),
        new Crop("Wheat",     10, 25,  50, 100, 40, 60),
        new Crop("Maize",     18, 27,  60, 150, 50, 70),
        new Crop("Sugarcane", 20, 40, 100, 300, 70, 90)
    };

    // All crops whose ranges match the weather
    public ArrayList<Crop> getSuitableCrops(WeatherData weather) {
        ArrayList<Crop> suitable = new ArrayList<>();
        for (Crop crop : crops) {
            if (crop.isSuitable(weather.getAverageTemperature(),
                                weather.getTotalRainfall(),
                                weather.getAverageHumidity())) {
                suitable.add(crop);
            }
        }
        return suitable;
    }

    // The best crop: the suitable one closest to the middle of its ranges. Null if none fit.
    public Crop recommend(WeatherData weather) {
        Crop best = null;
        double bestScore = Double.MAX_VALUE;

        for (Crop crop : getSuitableCrops(weather)) {
            double score = crop.fitScore(weather.getAverageTemperature(),
                                         weather.getTotalRainfall(),
                                         weather.getAverageHumidity());
            if (score < bestScore) {
                bestScore = score;
                best = crop;
            }
        }
        return best;
    }
}
