package model;

/**
 * A crop and the weather ranges it grows best in.
 */
public class Crop {

    private final String name;
    private final double minTemp, maxTemp;
    private final double minRain, maxRain;
    private final double minHumidity, maxHumidity;

    public Crop(String name, double minTemp, double maxTemp,
                double minRain, double maxRain,
                double minHumidity, double maxHumidity) {
        this.name = name;
        this.minTemp = minTemp;
        this.maxTemp = maxTemp;
        this.minRain = minRain;
        this.maxRain = maxRain;
        this.minHumidity = minHumidity;
        this.maxHumidity = maxHumidity;
    }

    public String getName() {
        return name;
    }

    // True only when all three weather values are inside this crop's ranges
    public boolean isSuitable(double avgTemp, double totalRain, double avgHumidity) {
        return avgTemp >= minTemp && avgTemp <= maxTemp
                && totalRain >= minRain && totalRain <= maxRain
                && avgHumidity >= minHumidity && avgHumidity <= maxHumidity;
    }

    // How far the weather is from the middle of the ranges (lower = better fit)
    public double fitScore(double avgTemp, double totalRain, double avgHumidity) {
        return deviation(avgTemp, minTemp, maxTemp)
                + deviation(totalRain, minRain, maxRain)
                + deviation(avgHumidity, minHumidity, maxHumidity);
    }

    public String getRequirements() {
        return "temperatures between " + (int) minTemp + "-" + (int) maxTemp + " C, rainfall of "
                + (int) minRain + "-" + (int) maxRain + " mm and humidity of "
                + (int) minHumidity + "-" + (int) maxHumidity + "%";
    }

    // 0 = exactly in the middle of the range, 1 = at the edge
    private static double deviation(double value, double min, double max) {
        double middle = (min + max) / 2;
        double halfRange = (max - min) / 2;
        return Math.abs(value - middle) / halfRange;
    }
}
