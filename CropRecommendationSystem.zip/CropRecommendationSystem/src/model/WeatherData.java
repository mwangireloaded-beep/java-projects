package model;

/**
 * Stores the daily weather readings for a period (15 days) and calculates the averages.
 */
public class WeatherData {

    private final double[] temperatures;
    private final double[] humidities;
    private final double[] rainfalls;
    private int daysRecorded = 0;

    public WeatherData(int numberOfDays) {
        temperatures = new double[numberOfDays];
        humidities = new double[numberOfDays];
        rainfalls = new double[numberOfDays];
    }

    // Stores one day's readings. Returns false if all days are already filled.
    public boolean addReading(double temperature, double humidity, double rainfall) {
        if (daysRecorded >= temperatures.length) {
            return false;
        }
        temperatures[daysRecorded] = temperature;
        humidities[daysRecorded] = humidity;
        rainfalls[daysRecorded] = rainfall;
        daysRecorded++;
        return true;
    }

    public int getDaysRecorded() {
        return daysRecorded;
    }

    public double getAverageTemperature() {
        return sum(temperatures) / daysRecorded;
    }

    public double getAverageHumidity() {
        return sum(humidities) / daysRecorded;
    }

    public double getTotalRainfall() {
        return sum(rainfalls);
    }

    private double sum(double[] values) {
        double total = 0;
        for (int i = 0; i < daysRecorded; i++) {
            total += values[i];
        }
        return total;
    }
}
