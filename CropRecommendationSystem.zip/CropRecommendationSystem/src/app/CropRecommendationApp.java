package app;

import model.Crop;
import model.WeatherData;
import service.CropRecommender;
import java.util.ArrayList;
import java.util.Scanner;

/**
 * Console interface for the Weather-Based Crop Recommendation System.
 */
public class CropRecommendationApp {

    private static final int DAYS = 15;

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Variables for one day's weather data
        double temperature, humidity, rainfall;

        // Object that holds the three 15-day arrays
        WeatherData weather = new WeatherData(DAYS);

        System.out.println("Welcome to the Weather-Based Crop Recommendation System!");
        System.out.println("Enter Weather Data for " + DAYS + " Days:\n");

        for (int day = 1; day <= DAYS; day++) {
            System.out.println("Day " + day + ":");
            temperature = readValue(input, "  Temperature (C): ", -10, 60);
            humidity = readValue(input, "  Humidity (%): ", 0, 100);
            rainfall = readValue(input, "  Rainfall (mm): ", 0, 500);
            weather.addReading(temperature, humidity, rainfall);
        }

        System.out.println("\nAnalyzing the weather data .......");
        System.out.printf("Average temperature : %.1f C%n", weather.getAverageTemperature());
        System.out.printf("Total rainfall      : %.1f mm%n", weather.getTotalRainfall());
        System.out.printf("Average humidity    : %.1f %%%n", weather.getAverageHumidity());

        CropRecommender recommender = new CropRecommender();
        Crop best = recommender.recommend(weather);

        System.out.println("\nBased on the weather trends:");
        if (best != null) {
            System.out.println("  * Recommended Crop: " + best.getName());
            System.out.println("      - Suitable for " + best.getRequirements());

            // List any other crops that also fit
            String others = "";
            for (Crop crop : recommender.getSuitableCrops(weather)) {
                if (crop != best) {
                    others += (others.isEmpty() ? "" : ", ") + crop.getName();
                }
            }
            if (!others.isEmpty()) {
                System.out.println("  * Other suitable crops: " + others);
            }
        } else {
            System.out.println("  * No crop matches these weather conditions.");
            System.out.println("      - Advice: wait for better conditions or consider irrigation.");
        }

        input.close();
    }

    // Reads a number and asks again if it is invalid or out of range
    private static double readValue(Scanner input, String prompt, double min, double max) {
        while (true) {
            System.out.print(prompt);
            if (input.hasNextDouble()) {
                double value = input.nextDouble();
                if (value >= min && value <= max) {
                    return value;
                }
                System.out.println("  Value must be between " + min + " and " + max + ". Try again.");
            } else {
                System.out.println("  Invalid input. Please enter a number.");
                input.next();
            }
        }
    }
}
