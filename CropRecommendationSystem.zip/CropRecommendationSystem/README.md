# Weather-Based Crop Recommendation System

```
CropRecommendationSystem/
  src/
    model/Crop.java                     one crop and its ranges
    model/WeatherData.java              15-day arrays and averages
    service/CropRecommender.java        crop table and recommendation logic
    app/CropRecommendationApp.java      input and output
```

Compile and run (from the CropRecommendationSystem folder):

    javac -d out src/model/*.java src/service/*.java src/app/*.java
    java -cp out app.CropRecommendationApp

In an IDE: create a Java project, copy the `src` folder in, and run `app.CropRecommendationApp`.
