/** Abstract base class for everyone the clinic stores. */
public abstract class Person {
    private final String id;
    private String name;

    protected Person(String id, String name) {
        this.id = id;
        this.name = checkName(name);
    }

    public static String checkName(String name) {
        return Text.required(name, "Name");
    }

    public String getId() { return id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = checkName(name); }

    public abstract String getRole();

    /** One line for the text file (pipe-separated, escaped). */
    public abstract String toFileLine();
}
