import java.time.LocalDate;

/** Summary and prescription written after an appointment. */
public class VisitRecord extends MedicalRecord {
    private final String appointmentId;
    private final String doctorId;
    private final String summary;
    private final String prescription;

    public VisitRecord(String recordId, String patientId, LocalDate date, String appointmentId,
                       String doctorId, String summary, String prescription) {
        super(recordId, patientId, date);
        this.appointmentId = appointmentId;
        this.doctorId = doctorId;
        this.summary = Text.required(summary, "Visit summary");
        this.prescription = (prescription == null || prescription.trim().isEmpty())
                ? "None" : prescription.trim();
    }

    public String getAppointmentId() { return appointmentId; }
    public String getDoctorId() { return doctorId; }
    public String getSummary() { return summary; }
    public String getPrescription() { return prescription; }

    @Override
    public String getType() { return "VISIT"; }

    @Override
    public String describe() {
        return "[" + getRecordId() + "] Visit on " + getDate() + " (appointment " + appointmentId
                + ", doctor " + doctorId + ")\n"
                + "      Summary:      " + summary + "\n"
                + "      Prescription: " + prescription;
    }

    @Override
    public String toFileLine() {
        return Text.join("VISIT", getRecordId(), getPatientId(), getDate(),
                appointmentId, doctorId, summary, prescription);
    }
}
