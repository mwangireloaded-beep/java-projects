import java.time.LocalDate;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class PatientManager {
    private final Map<String, Patient> patients = new LinkedHashMap<>();
    private int counter = 0;

    public Patient register(String name, LocalDate dob, String bloodGroup,
                            String allergies, String contact) {
        Patient p = new Patient(Text.makeId('P', counter + 1), name, dob, bloodGroup, allergies, contact);
        counter++;
        patients.put(p.getId(), p);
        return p;
    }

    /** Used when loading from file: keeps the saved ID and moves the counter on. */
    public void addLoaded(Patient p) {
        patients.put(p.getId(), p);
        counter = Math.max(counter, Text.idNumber(p.getId()));
    }

    public Patient get(String id) {
        Patient p = patients.get(id.trim().toUpperCase());
        if (p == null) throw new NotFoundException("No patient with ID " + id.trim() + ".");
        return p;
    }

    /** Matches the ID or any part of the name, ignoring case. */
    public List<Patient> search(String query) {
        String q = query.trim().toLowerCase();
        List<Patient> found = new ArrayList<>();
        for (Patient p : patients.values()) {
            if (p.getId().toLowerCase().equals(q) || p.getName().toLowerCase().contains(q)) {
                found.add(p);
            }
        }
        return found;
    }

    public List<Patient> all() { return new ArrayList<>(patients.values()); }
    public int count() { return patients.size(); }
}
