import java.time.LocalDate;

/** Abstract base for anything added to a patient's medical history. */
public abstract class MedicalRecord {
    private final String recordId;
    private final String patientId;
    private final LocalDate date;

    protected MedicalRecord(String recordId, String patientId, LocalDate date) {
        this.recordId = recordId;
        this.patientId = patientId;
        this.date = date;
    }

    public String getRecordId() { return recordId; }
    public String getPatientId() { return patientId; }
    public LocalDate getDate() { return date; }

    public abstract String getType();

    /** Multi-line text shown in the patient history. */
    public abstract String describe();

    public abstract String toFileLine();
}
