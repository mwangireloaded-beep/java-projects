/** Checked exception thrown when a booking clashes with an existing appointment. */
public class DoubleBookingException extends Exception {
    private static final long serialVersionUID = 1L;

    public DoubleBookingException(String message) {
        super(message);
    }
}
