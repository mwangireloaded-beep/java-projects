import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.NoSuchElementException;

/** Console menu for the clinic system. */
public class Main {
    private static final PatientManager patients = new PatientManager();
    private static final DoctorManager doctors = new DoctorManager();
    private static final AppointmentManager appointments = new AppointmentManager();
    private static final RecordManager records = new RecordManager();
    private static final FileStorage storage = new FileStorage("data");
    private static final Input in = new Input();

    public static void main(String[] args) {
        System.out.println("=== Clinic Appointments & Patient Records ===");
        try {
            storage.loadAll(patients, doctors, appointments, records);
            System.out.println("Loaded " + patients.count() + " patients, " + doctors.count()
                    + " doctors, " + appointments.count() + " appointments, "
                    + records.count() + " records.");
        } catch (IOException e) {
            System.out.println("Could not read saved data: " + e.getMessage());
        }

        try {
            boolean running = true;
            while (running) {
                printMenu();
                int choice = in.choice("Choose an option", 0, 12);
                try {
                    switch (choice) {
                        case 1: registerPatient(); break;
                        case 2: registerDoctor(); break;
                        case 3: listPatients(); break;
                        case 4: listDoctors(); break;
                        case 5: searchPatients(); break;
                        case 6: bookAppointment(); break;
                        case 7: cancelAppointment(); break;
                        case 8: viewAppointments(); break;
                        case 9: recordVisit(); break;
                        case 10: addLabRecord(); break;
                        case 11: patientHistory(); break;
                        case 12: patientBill(); break;
                        default: running = false; break;
                    }
                } catch (DoubleBookingException e) {
                    System.out.println("  ! Booking refused: " + e.getMessage());
                } catch (NotFoundException | InvalidDataException e) {
                    System.out.println("  ! " + e.getMessage());
                }
            }
        } catch (NoSuchElementException e) {
            System.out.println("\n(input closed)");
        }
        save();
        System.out.println("Data saved. Goodbye.");
    }

    private static void printMenu() {
        System.out.println("\n 1) Register patient      7) Cancel appointment");
        System.out.println(" 2) Register doctor       8) View appointments");
        System.out.println(" 3) List patients         9) Record visit + prescription");
        System.out.println(" 4) List doctors         10) Add lab record");
        System.out.println(" 5) Search patient       11) Patient history");
        System.out.println(" 6) Book appointment     12) Patient bill");
        System.out.println(" 0) Save and exit");
    }

    private static void save() {
        try {
            storage.saveAll(patients, doctors, appointments, records);
        } catch (IOException e) {
            System.out.println("  ! Could not save data: " + e.getMessage());
        }
    }

    // ---------- registration ----------

    private static void registerPatient() {
        String name = in.ask("Full name", Person::checkName);
        LocalDate dob = in.ask("Date of birth (yyyy-MM-dd)", s -> Patient.checkDob(Text.parseDate(s)));
        String blood = in.ask("Blood group (A+ A- B+ B- AB+ AB- O+ O-)", Patient::checkBloodGroup);
        String allergies = in.optional("Allergies (blank for none)");
        String contact = in.ask("Contact phone", Patient::checkContact);

        Patient p = patients.register(name, dob, blood, allergies, contact);
        save();
        System.out.println("Registered patient " + p.getId() + ": " + p.getName());
    }

    private static void registerDoctor() {
        String name = in.ask("Doctor's name", Person::checkName);
        String specialty = in.ask("Specialty", s -> Text.required(s, "Specialty"));
        final LocalTime start = in.ask("Working hours start (HH:mm)", Text::parseTime);
        LocalTime end = in.ask("Working hours end (HH:mm)", s -> {
            LocalTime t = Text.parseTime(s);
            Doctor.checkHours(start, t);
            return t;
        });
        double fee = in.ask("Consultation fee (KES)", Text::parseMoney);

        Doctor d = doctors.register(name, specialty, start, end, fee);
        save();
        System.out.println("Registered " + d.getDisplayName() + " as " + d.getId());
    }

    private static void listPatients() {
        if (patients.count() == 0) { System.out.println("No patients yet."); return; }
        for (Patient p : patients.all()) System.out.println(p);
    }

    private static void listDoctors() {
        if (doctors.count() == 0) { System.out.println("No doctors yet."); return; }
        for (Doctor d : doctors.all()) System.out.println(d);
    }

    private static void searchPatients() {
        String query = in.text("Search by ID or name");
        List<Patient> found = patients.search(query);
        if (found.isEmpty()) System.out.println("No match.");
        for (Patient p : found) System.out.println(p);
    }

    // ---------- appointments ----------

    private static void bookAppointment() throws DoubleBookingException {
        if (patients.count() == 0 || doctors.count() == 0) {
            System.out.println("Register at least one patient and one doctor first.");
            return;
        }
        listPatients();
        Patient patient = patients.get(in.text("Patient ID"));
        listDoctors();
        Doctor doctor = doctors.get(in.text("Doctor ID"));
        LocalDate date = in.ask("Date (yyyy-MM-dd)", s -> {
            LocalDate d = Text.parseDate(s);
            if (d.isBefore(LocalDate.now())) throw new InvalidDataException("That date has already passed.");
            return d;
        });

        List<LocalTime> free = appointments.freeSlots(doctor, date);
        if (free.isEmpty()) {
            System.out.println("  ! " + doctor.getDisplayName() + " has no free slots on " + date + ".");
            return;
        }
        System.out.println("Free slots: " + free);
        LocalTime time = in.ask("Start time (HH:mm)", Text::parseTime);

        Appointment a = appointments.book(patient, doctor, date, time);
        save();
        System.out.println("Booked " + a.getId() + ": " + a);
    }

    private static void cancelAppointment() {
        Appointment a = appointments.cancel(in.text("Appointment ID"));
        save();
        System.out.println("Cancelled " + a.getId() + ".");
    }

    private static void viewAppointments() {
        System.out.println("1) All   2) By doctor   3) By patient");
        int choice = in.choice("Show", 1, 3);
        List<Appointment> list;
        if (choice == 2) list = appointments.forDoctor(doctors.get(in.text("Doctor ID")).getId());
        else if (choice == 3) list = appointments.forPatient(patients.get(in.text("Patient ID")).getId());
        else list = appointments.all();

        if (list.isEmpty()) System.out.println("No appointments.");
        for (Appointment a : list) System.out.println(a);
    }

    // ---------- records ----------

    private static void recordVisit() {
        Appointment a = appointments.get(in.text("Appointment ID"));
        if (!a.isBooked()) {
            throw new InvalidDataException("Appointment " + a.getId() + " is " + a.getStatus()
                    + "; only booked appointments can be completed.");
        }
        System.out.println(a);
        String summary = in.text("Visit summary");
        String prescription = in.optional("Prescription (blank for none)");

        VisitRecord v = records.addVisit(a, summary, prescription);
        a.markCompleted();
        save();
        System.out.println("Saved visit record " + v.getRecordId() + " and marked "
                + a.getId() + " as completed.");
    }

    private static void addLabRecord() {
        Patient p = patients.get(in.text("Patient ID"));
        String test = in.text("Test name");
        String result = in.text("Result");
        double fee = in.ask("Fee (KES)", Text::parseMoney);

        LabRecord l = records.addLab(p, test, result, fee);
        save();
        System.out.println("Saved lab record " + l.getRecordId() + " for " + p.getName() + ".");
    }

    private static void patientHistory() {
        Patient p = patients.get(in.text("Patient ID"));
        System.out.println("\n" + p);
        System.out.println("\nAppointments:");
        List<Appointment> appts = appointments.forPatient(p.getId());
        if (appts.isEmpty()) System.out.println("  none");
        for (Appointment a : appts) System.out.println("  " + a);

        System.out.println("\nMedical records:");
        List<MedicalRecord> recs = records.forPatient(p.getId());
        if (recs.isEmpty()) System.out.println("  none");
        for (MedicalRecord r : recs) System.out.println("  " + r.describe());
    }

    private static void patientBill() {
        Patient p = patients.get(in.text("Patient ID"));
        List<Billable> items = new ArrayList<>();
        for (Appointment a : appointments.forPatient(p.getId())) {
            if (a.getStatus() == Appointment.Status.COMPLETED) items.add(a);
        }
        for (MedicalRecord r : records.forPatient(p.getId())) {
            if (r instanceof Billable) items.add((Billable) r);
        }

        System.out.println("\nBill for " + p.getName() + " (" + p.getId() + ")");
        double total = 0;
        for (Billable b : items) {
            System.out.printf("  %-52s KES %,10.2f%n", b.getBillDescription(), b.getFee());
            total += b.getFee();
        }
        if (items.isEmpty()) System.out.println("  Nothing to bill yet.");
        System.out.printf("  %-52s KES %,10.2f%n", "TOTAL", total);
    }
}
