import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class RecordManager {
    private final List<MedicalRecord> records = new ArrayList<>();
    private int counter = 0;

    public VisitRecord addVisit(Appointment appt, String summary, String prescription) {
        for (MedicalRecord r : records) {
            if (r instanceof VisitRecord
                    && ((VisitRecord) r).getAppointmentId().equals(appt.getId())) {
                throw new InvalidDataException("Appointment " + appt.getId() + " already has a visit record.");
            }
        }
        VisitRecord v = new VisitRecord(Text.makeId('R', counter + 1), appt.getPatient().getId(),
                LocalDate.now(), appt.getId(), appt.getDoctor().getId(), summary, prescription);
        counter++;
        records.add(v);
        return v;
    }

    public LabRecord addLab(Patient patient, String test, String result, double fee) {
        LabRecord l = new LabRecord(Text.makeId('R', counter + 1), patient.getId(),
                LocalDate.now(), test, result, fee);
        counter++;
        records.add(l);
        return l;
    }

    public void addLoaded(MedicalRecord r) {
        records.add(r);
        counter = Math.max(counter, Text.idNumber(r.getRecordId()));
    }

    public List<MedicalRecord> forPatient(String patientId) {
        List<MedicalRecord> list = new ArrayList<>();
        for (MedicalRecord r : records) {
            if (r.getPatientId().equals(patientId)) list.add(r);
        }
        list.sort(Comparator.comparing(MedicalRecord::getDate));
        return list;
    }

    public List<MedicalRecord> all() { return new ArrayList<>(records); }
    public int count() { return records.size(); }
}
