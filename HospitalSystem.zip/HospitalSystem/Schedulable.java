import java.time.LocalDate;
import java.time.LocalTime;

/** Anything that occupies a time slot on a given date. */
public interface Schedulable {
    LocalDate getDate();
    LocalTime getStartTime();
    LocalTime getEndTime();

    /** True when both items are on the same date and their time ranges overlap. */
    default boolean overlapsWith(Schedulable other) {
        return getDate().equals(other.getDate())
                && getStartTime().isBefore(other.getEndTime())
                && other.getStartTime().isBefore(getEndTime());
    }
}
