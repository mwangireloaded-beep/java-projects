import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeParseException;
import java.time.temporal.ChronoUnit;

/** Helpers for parsing user input and for reading/writing the text-file fields. */
public final class Text {
    private Text() { }

    // ---------- input parsing (each throws InvalidDataException on bad input) ----------

    public static String required(String s, String label) {
        if (s == null || s.trim().isEmpty()) {
            throw new InvalidDataException(label + " cannot be empty.");
        }
        return s.trim();
    }

    public static LocalDate parseDate(String s) {
        try {
            return LocalDate.parse(s.trim());
        } catch (DateTimeParseException e) {
            throw new InvalidDataException("Use the format yyyy-MM-dd (e.g. 2026-11-05).");
        }
    }

    public static LocalTime parseTime(String s) {
        try {
            return LocalTime.parse(s.trim()).truncatedTo(ChronoUnit.MINUTES);
        } catch (DateTimeParseException e) {
            throw new InvalidDataException("Use 24-hour time HH:mm (e.g. 09:30).");
        }
    }

    public static double parseMoney(String s) {
        double value;
        try {
            value = Double.parseDouble(s.trim());
        } catch (NumberFormatException e) {
            throw new InvalidDataException("Enter a number, e.g. 1500.");
        }
        if (Double.isNaN(value) || Double.isInfinite(value) || value < 0) {
            throw new InvalidDataException("Amount must be zero or more.");
        }
        return value;
    }

    // ---------- text-file encoding: fields separated by '|' ----------

    /** Escapes backslash, pipe and newline so a value is safe inside one line. */
    public static String esc(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("|", "\\p").replace("\r", "").replace("\n", "\\n");
    }

    public static String unesc(String s) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            if (c == '\\' && i + 1 < s.length()) {
                char next = s.charAt(++i);
                if (next == 'p') sb.append('|');
                else if (next == 'n') sb.append('\n');
                else sb.append(next);
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    /** Joins values into one escaped, pipe-separated line. */
    public static String join(Object... values) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < values.length; i++) {
            if (i > 0) sb.append('|');
            sb.append(esc(String.valueOf(values[i])));
        }
        return sb.toString();
    }

    /** Splits a saved line back into unescaped fields. */
    public static String[] fields(String line) {
        String[] parts = line.split("\\|", -1);
        for (int i = 0; i < parts.length; i++) {
            parts[i] = unesc(parts[i]);
        }
        return parts;
    }

    // ---------- IDs like P001, D002, A010 ----------

    public static String makeId(char prefix, int number) {
        return String.format("%c%03d", prefix, number);
    }

    public static int idNumber(String id) {
        try {
            return Integer.parseInt(id.substring(1));
        } catch (RuntimeException e) {
            return 0;
        }
    }

    public static String clip(String s, int max) {
        return s.length() <= max ? s : s.substring(0, max - 1) + "~";
    }
}
