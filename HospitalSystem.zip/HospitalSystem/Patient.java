import java.time.LocalDate;
import java.time.Period;
import java.util.Arrays;
import java.util.List;

public class Patient extends Person {
    public static final List<String> BLOOD_GROUPS =
            Arrays.asList("A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-");

    private final LocalDate dateOfBirth;
    private final String bloodGroup;
    private String allergies;
    private String contact;

    public Patient(String id, String name, LocalDate dateOfBirth, String bloodGroup,
                   String allergies, String contact) {
        super(id, name);
        this.dateOfBirth = checkDob(dateOfBirth);
        this.bloodGroup = checkBloodGroup(bloodGroup);
        this.allergies = (allergies == null || allergies.trim().isEmpty()) ? "None" : allergies.trim();
        this.contact = checkContact(contact);
    }

    public static LocalDate checkDob(LocalDate dob) {
        if (dob == null || dob.isAfter(LocalDate.now())) {
            throw new InvalidDataException("Date of birth must be today or earlier.");
        }
        return dob;
    }

    public static String checkBloodGroup(String bg) {
        String value = bg == null ? "" : bg.trim().toUpperCase();
        if (!BLOOD_GROUPS.contains(value)) {
            throw new InvalidDataException("Blood group must be one of " + BLOOD_GROUPS + ".");
        }
        return value;
    }

    public static String checkContact(String contact) {
        String value = contact == null ? "" : contact.trim().replace(" ", "");
        if (!value.matches("\\+?[0-9]{7,15}")) {
            throw new InvalidDataException("Contact must be 7-15 digits (a leading + is allowed).");
        }
        return value;
    }

    public LocalDate getDateOfBirth() { return dateOfBirth; }
    public String getBloodGroup() { return bloodGroup; }
    public String getAllergies() { return allergies; }
    public String getContact() { return contact; }
    public int getAge() { return Period.between(dateOfBirth, LocalDate.now()).getYears(); }

    public void setContact(String contact) { this.contact = checkContact(contact); }

    @Override
    public String getRole() { return "Patient"; }

    @Override
    public String toFileLine() {
        return Text.join(getId(), getName(), dateOfBirth, bloodGroup, allergies, contact);
    }

    @Override
    public String toString() {
        return String.format("%-5s %-22s %3d yrs  %-3s  Tel: %-13s Allergies: %s",
                getId(), Text.clip(getName(), 22), getAge(), bloodGroup, contact, allergies);
    }
}
