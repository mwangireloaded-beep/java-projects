/** Anything the clinic charges for (consultations, lab tests, procedures). */
public interface Billable {
    double getFee();
    String getBillDescription();
}
