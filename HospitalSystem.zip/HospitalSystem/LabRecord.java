import java.time.LocalDate;

/** A lab test and its result. It is billable. */
public class LabRecord extends MedicalRecord implements Billable {
    private final String testName;
    private final String result;
    private final double fee;

    public LabRecord(String recordId, String patientId, LocalDate date,
                     String testName, String result, double fee) {
        super(recordId, patientId, date);
        this.testName = Text.required(testName, "Test name");
        this.result = Text.required(result, "Result");
        this.fee = Doctor.checkFee(fee);
    }

    public String getTestName() { return testName; }
    public String getResult() { return result; }

    @Override
    public double getFee() { return fee; }

    @Override
    public String getBillDescription() { return "Lab test: " + testName + " (" + getDate() + ")"; }

    @Override
    public String getType() { return "LAB"; }

    @Override
    public String describe() {
        return "[" + getRecordId() + "] Lab test on " + getDate() + ": " + testName + "\n"
                + "      Result: " + result;
    }

    @Override
    public String toFileLine() {
        return Text.join("LAB", getRecordId(), getPatientId(), getDate(), testName, result, fee);
    }
}
