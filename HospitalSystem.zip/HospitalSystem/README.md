# Hospital Appointment and Patient Records (Java OOP, Project 3)

## Run it
```
javac *.java
java Main
```
Data is saved in a `data/` folder next to where you run it (patients.txt, doctors.txt,
appointments.txt, records.txt) and reloaded on startup. It saves after every change.

## Classes
| Part | Classes |
|---|---|
| Inheritance | `Person` -> `Patient`, `Doctor`; `MedicalRecord` -> `VisitRecord`, `LabRecord` |
| Interfaces | `Schedulable` (Appointment), `Billable` (Appointment, LabRecord) |
| Custom exceptions | `DoubleBookingException`, `NotFoundException`, `InvalidDataException` |
| Managers | `PatientManager`, `DoctorManager`, `AppointmentManager`, `RecordManager` |
| File handling | `FileStorage`, helpers in `Text` |
| Console | `Input`, `Main` |

## Freedom points chosen
- Appointments last 30 minutes (`Appointment.DURATION_MINUTES`)
- Fee = the doctor's consultation fee in KES, frozen when the appointment is booked
- Extras: free-slot listing, cancellation, patient clash check, lab tests, patient bill

## Quick demo
1. Register a patient (1) and a doctor (2)
2. Book an appointment (6), then try booking the same slot again to see the double-booking error
3. Record a visit (9), add a lab test (10), view history (11) and bill (12)
4. Exit (0), run again, and everything is still there
