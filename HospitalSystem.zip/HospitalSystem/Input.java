import java.util.Scanner;
import java.util.function.Function;

/** Console input that keeps asking until the answer is valid. */
public class Input {
    private final Scanner scanner = new Scanner(System.in);

    /** Asks until the parser accepts the answer (the parser throws InvalidDataException if not). */
    public <T> T ask(String prompt, Function<String, T> parser) {
        while (true) {
            System.out.print(prompt + ": ");
            String line = scanner.nextLine();
            try {
                return parser.apply(line);
            } catch (InvalidDataException e) {
                System.out.println("  ! " + e.getMessage());
            }
        }
    }

    public String text(String prompt) {
        return ask(prompt, s -> Text.required(s, "This field"));
    }

    public String optional(String prompt) {
        System.out.print(prompt + ": ");
        return scanner.nextLine().trim();
    }

    public int choice(String prompt, int min, int max) {
        return ask(prompt + " [" + min + "-" + max + "]", s -> {
            int value;
            try {
                value = Integer.parseInt(s.trim());
            } catch (NumberFormatException e) {
                throw new InvalidDataException("Enter a number.");
            }
            if (value < min || value > max) {
                throw new InvalidDataException("Pick a number from " + min + " to " + max + ".");
            }
            return value;
        });
    }
}
