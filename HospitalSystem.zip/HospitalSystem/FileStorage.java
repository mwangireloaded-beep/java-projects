import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/** Saves and loads everything as pipe-separated text files inside one folder. */
public class FileStorage {
    private final Path dir;

    public FileStorage(String folder) {
        this.dir = Paths.get(folder);
    }

    public void saveAll(PatientManager pm, DoctorManager dm, AppointmentManager am,
                        RecordManager rm) throws IOException {
        Files.createDirectories(dir);

        List<String> lines = new ArrayList<>();
        for (Patient p : pm.all()) lines.add(p.toFileLine());
        write("patients.txt", lines);

        lines = new ArrayList<>();
        for (Doctor d : dm.all()) lines.add(d.toFileLine());
        write("doctors.txt", lines);

        lines = new ArrayList<>();
        for (Appointment a : am.all()) lines.add(a.toFileLine());
        write("appointments.txt", lines);

        lines = new ArrayList<>();
        for (MedicalRecord r : rm.all()) lines.add(r.toFileLine());
        write("records.txt", lines);
    }

    /** Patients and doctors load first because appointments and records refer to them. */
    public void loadAll(PatientManager pm, DoctorManager dm, AppointmentManager am,
                        RecordManager rm) throws IOException {
        for (String line : read("patients.txt")) {
            try {
                String[] f = Text.fields(line);
                pm.addLoaded(new Patient(f[0], f[1], LocalDate.parse(f[2]), f[3], f[4], f[5]));
            } catch (RuntimeException e) {
                warn("patients.txt", line, e);
            }
        }
        for (String line : read("doctors.txt")) {
            try {
                String[] f = Text.fields(line);
                dm.addLoaded(new Doctor(f[0], f[1], f[2], LocalTime.parse(f[3]),
                        LocalTime.parse(f[4]), Double.parseDouble(f[5])));
            } catch (RuntimeException e) {
                warn("doctors.txt", line, e);
            }
        }
        for (String line : read("appointments.txt")) {
            try {
                String[] f = Text.fields(line);
                am.addLoaded(new Appointment(f[0], pm.get(f[1]), dm.get(f[2]), LocalDate.parse(f[3]),
                        LocalTime.parse(f[4]), Double.parseDouble(f[5]), Appointment.Status.valueOf(f[6])));
            } catch (RuntimeException e) {
                warn("appointments.txt", line, e);
            }
        }
        for (String line : read("records.txt")) {
            try {
                String[] f = Text.fields(line);
                if (f[0].equals("VISIT")) {
                    rm.addLoaded(new VisitRecord(f[1], f[2], LocalDate.parse(f[3]), f[4], f[5], f[6], f[7]));
                } else if (f[0].equals("LAB")) {
                    rm.addLoaded(new LabRecord(f[1], f[2], LocalDate.parse(f[3]), f[4], f[5],
                            Double.parseDouble(f[6])));
                } else {
                    throw new InvalidDataException("Unknown record type " + f[0]);
                }
            } catch (RuntimeException e) {
                warn("records.txt", line, e);
            }
        }
    }

    /** Writes to a temp file first so a crash cannot leave a half-written data file. */
    private void write(String name, List<String> lines) throws IOException {
        Path tmp = dir.resolve(name + ".tmp");
        Files.write(tmp, lines, StandardCharsets.UTF_8);
        Files.move(tmp, dir.resolve(name), StandardCopyOption.REPLACE_EXISTING);
    }

    private List<String> read(String name) throws IOException {
        Path file = dir.resolve(name);
        List<String> lines = new ArrayList<>();
        if (!Files.exists(file)) return lines;
        for (String line : Files.readAllLines(file, StandardCharsets.UTF_8)) {
            if (!line.trim().isEmpty()) lines.add(line);
        }
        return lines;
    }

    private void warn(String file, String line, RuntimeException e) {
        System.out.println("  ! Skipped a bad line in " + file + " (" + e.getMessage() + "): " + line);
    }
}
