import java.time.LocalTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class DoctorManager {
    private final Map<String, Doctor> doctors = new LinkedHashMap<>();
    private int counter = 0;

    public Doctor register(String name, String specialty, LocalTime start, LocalTime end, double fee) {
        Doctor d = new Doctor(Text.makeId('D', counter + 1), name, specialty, start, end, fee);
        counter++;
        doctors.put(d.getId(), d);
        return d;
    }

    public void addLoaded(Doctor d) {
        doctors.put(d.getId(), d);
        counter = Math.max(counter, Text.idNumber(d.getId()));
    }

    public Doctor get(String id) {
        Doctor d = doctors.get(id.trim().toUpperCase());
        if (d == null) throw new NotFoundException("No doctor with ID " + id.trim() + ".");
        return d;
    }

    public List<Doctor> all() { return new ArrayList<>(doctors.values()); }
    public int count() { return doctors.size(); }
}
